import { useState, Fragment } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MessageSquare, HelpCircle, FileText, PackageSearch, Instagram, Youtube, MessageCircle, X, ChevronDown } from "lucide-react";

const faqs = [
  { q: "Qual o prazo de entrega?", a: "O prazo varia de acordo com a sua região e a forma de envio escolhida (PAC ou Sedex), geralmente entre 5 a 15 dias úteis." },
  { q: "Como posso rastrear meu pedido?", a: "Assim que enviarmos seu pacote, disponibilizaremos o código de rastreio para você acompanhar pelo site dos Correios ou no próprio link de rastreio que deixamos na Bio." },
  { q: "Quais são as formas de pagamento?", a: "Aceitamos Pix (com aprovação imediata e desconto), Cartões de Crédito (em até 6x sem juros) e Boleto Bancário." },
  { q: "Posso alterar o endereço de entrega após a compra?", a: "Pelo nosso sistema automatizado, não é possível alterar o endereço se o pedido já estiver faturado ou enviado. Se você acabou de comprar, chame no WhatsApp com urgência!" },
  { q: "Fazem envio internacional?", a: "No momento, enviamos somente para todo o território nacional (Brasil)." },
  { q: "Qual é o tamanho das peças?", a: "A maioria das nossas peças segue um padrão streetwear (oversized). Recomendamos fortemente verificar a tabela de medidas disponível na descrição de cada produto." },
  { q: "Posso cancelar minha compra?", a: "Sim, você pode pedir o cancelamento do pedido antes do envio. Caso já tenha sido enviado, precisará recusar a entrega ou solicitar a devolução." },
  { q: "As peças encolhem ao lavar?", a: "Nossas camisetas e moletons passam por pré-encolhimento. Porém, recomendamos lavar à mão e não usar secadora para manter a durabilidade da estampa e do tecido ao máximo." },
  { q: "Como fico sabendo dos lançamentos?", a: "Acompanhe nosso Instagram e ative as notificações! Os drops são limitadíssimos e as peças esgotam rápido." }
];

const policies = [
  { q: "Trocas e Devoluções", a: "O cliente tem até 7 dias corridos após o recebimento para solicitar troca ou devolução (direito de arrependimento). A peça não pode apresentar sinais de uso, odores ou lavagem, e deve estar com as etiquetas originais afixadas." },
  { q: "Defeito de Fabricação", a: "Caso o produto apresente algum tipo de defeito de fabricação, oferecemos garantia de 30 dias após o recebimento. Solicite a análise diretamente no nosso WhatsApp." },
  { q: "Privacidade e Dados", a: "Usamos seus dados de navegação e de conta apenas para processamento de pedidos e envio de promoções, respeitando integralmente a LGPD (Lei Geral de Proteção de Dados)." },
  { q: "Prazos e Extravios", a: "Caso haja roubo ou extravio do pacote comprovado pelos Correios, nós nos responsabilizamos pelo envio de novas peças ou faremos o reembolso total do valor, conforme sua preferência." }
];

const Accordion = ({ title, content }: { title: string, content: string }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-zinc-800 last:border-0">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-4 flex items-center justify-between text-left focus:outline-none hover:text-neon-green transition-colors"
      >
        <span className="font-bold tracking-widest uppercase text-xs sm:text-sm">{title}</span>
        <motion.div animate={{ rotate: isOpen ? 180 : 0 }}>
          <ChevronDown className="w-5 h-5 text-neon-green" />
        </motion.div>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <p className="pb-4 text-zinc-400 text-sm leading-relaxed">
              {content}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const Modal = ({ isOpen, onClose, title, children }: { isOpen: boolean, onClose: () => void, title: string, children: React.ReactNode }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <Fragment>
          {/* Backdrop */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm"
          />
          {/* Modal Container */}
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className="w-full max-w-lg bg-zinc-950 border-2 border-neon-green flex flex-col max-h-[85vh] pointer-events-auto relative shadow-[8px_8px_0px_0px_rgba(57,255,20,0.5)]"
            >
              {/* Header */}
              <div className="flex items-center justify-between p-6 pb-4 border-b border-zinc-900 flex-shrink-0">
                <h2 className="font-marker text-2xl text-white tracking-wide pr-4">{title}</h2>
                <button 
                  onClick={onClose}
                  className="text-zinc-400 hover:text-neon-green transition-colors focus:outline-none"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              {/* Scrollable Content */}
              <div className="flex flex-col p-6 pt-2 overflow-y-auto scrollbar-hide flex-grow">
                {children}
              </div>
            </motion.div>
          </div>
        </Fragment>
      )}
    </AnimatePresence>
  );
};

export default function App() {
  const [isFaqOpen, setIsFaqOpen] = useState(false);
  const [isPolicyOpen, setIsPolicyOpen] = useState(false);

  const links = [
    {
      title: "Atendimento",
      icon: <MessageSquare className="w-5 h-5 mr-3" />,
      url: "https://wa.me/5514999081316",
      delay: 0.1,
    },
    {
      title: "Dúvidas Gerais",
      icon: <HelpCircle className="w-5 h-5 mr-3" />,
      onClick: () => setIsFaqOpen(true),
      delay: 0.2,
    },
    {
      title: "Políticas da Loja",
      icon: <FileText className="w-5 h-5 mr-3" />,
      onClick: () => setIsPolicyOpen(true),
      delay: 0.3,
    },
    {
      title: "Rastrear meu Pedido",
      icon: <PackageSearch className="w-5 h-5 mr-3" />,
      url: "https://rastreamento.correios.com.br/app/index.php",
      delay: 0.4,
    },
  ];

  return (
    <div 
      className="min-h-screen bg-black text-white font-space relative overflow-hidden flex flex-col items-center py-12 px-6 selection:bg-neon-green selection:text-black bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: "linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.8)), url('https://i.postimg.cc/76JTrV3k/Chat-GPT-Image-23-de-mai-de-2026-22-24-42.png')" }}
    >
      {/* Modals */}
      <Modal isOpen={isFaqOpen} onClose={() => setIsFaqOpen(false)} title="Dúvidas Gerais">
        {faqs.map((faq, idx) => (
          <Accordion key={idx} title={faq.q} content={faq.a} />
        ))}
      </Modal>

      <Modal isOpen={isPolicyOpen} onClose={() => setIsPolicyOpen(false)} title="Políticas da Loja">
        {policies.map((policy, idx) => (
          <Accordion key={idx} title={policy.q} content={policy.a} />
        ))}
      </Modal>

      {/* Graffiti/Grunge Background Texture Elements */}
      <div className="absolute top-[-10%] left-[-10%] sm:left-[10%] opacity-10 pointer-events-none select-none">
         <span className="font-marker text-[150px] leading-none text-neon-green" style={{ transform: 'rotate(-15deg)', display: 'inline-block' }}>STREET</span>
      </div>
      <div className="absolute bottom-[5%] right-[-10%] sm:right-[10%] opacity-10 pointer-events-none select-none">
         <span className="font-marker text-[120px] leading-none text-white" style={{ transform: 'rotate(10deg)', display: 'inline-block' }}>WEAR</span>
      </div>

      <div className="w-full max-w-md relative z-10 flex flex-col items-center gap-8">
        
        {/* Header Section */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center gap-4 text-center mt-8"
        >
          {/* Logo / PFP Placeholder */}
          <div className="w-28 h-28 rounded-full border-4 border-neon-green p-1 relative group">
            <div className="w-full h-full bg-zinc-900 rounded-full flex items-center justify-center overflow-hidden">
               <img 
                 src="https://i.postimg.cc/cHCrMc9q/Chat-GPT-Image-23-de-mai-de-2026-19-51-38.png" 
                 alt="Store Logo" 
                 className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
               />
            </div>
          </div>

          <div>
            <h1 className="font-marker text-3xl sm:text-4xl text-white tracking-wider mt-2 mb-1">
              URBANYLE
            </h1>
            <p className="text-zinc-400 text-sm font-bold tracking-[0.2em] uppercase">
              Underground Culture
            </p>
          </div>
        </motion.div>

        {/* Links Section */}
        <div className="w-full flex flex-col gap-4 mt-4">
          {links.map((link, index) => {
            const Wrapper = link.url ? motion.a : motion.button;
            const props = link.url 
              ? { href: link.url, target: "_blank", rel: "noopener noreferrer" }
              : { onClick: link.onClick };
              
            return (
              <Wrapper
                key={index}
                {...props}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: link.delay }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="group relative w-full bg-transparent border-2 border-zinc-800 hover:border-neon-green p-4 flex items-center justify-center overflow-hidden transition-colors duration-300 text-left focus:outline-none"
              >
                <div className="absolute inset-0 bg-neon-green translate-y-[100%] group-hover:translate-y-0 transition-transform duration-300 ease-in-out z-0"></div>
                
                <div className="relative z-10 flex items-center justify-center w-full group-hover:text-black transition-colors duration-300">
                   {link.icon}
                   <span className="font-bold tracking-widest uppercase text-sm sm:text-base">
                     {link.title}
                   </span>
                </div>
              </Wrapper>
            );
          })}
        </div>

        {/* Footer / Socials */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="flex items-center gap-6 mt-8"
        >
          <a href="#" className="p-3 bg-zinc-900 hover:bg-neon-green text-zinc-400 hover:text-black transition-all duration-300 shadow-[4px_4px_0px_0px_rgba(57,255,20,0.5)] hover:shadow-none hover:translate-x-[4px] hover:translate-y-[4px]">
            <Instagram className="w-6 h-6" />
          </a>
          <a href="#" className="p-3 bg-zinc-900 hover:bg-neon-green text-zinc-400 hover:text-black transition-all duration-300 shadow-[4px_4px_0px_0px_rgba(57,255,20,0.5)] hover:shadow-none hover:translate-x-[4px] hover:translate-y-[4px]">
            <Youtube className="w-6 h-6" />
          </a>
          <a href="#" className="p-3 bg-zinc-900 hover:bg-neon-green text-zinc-400 hover:text-black transition-all duration-300 shadow-[4px_4px_0px_0px_rgba(57,255,20,0.5)] hover:shadow-none hover:translate-x-[4px] hover:translate-y-[4px]">
            <MessageCircle className="w-6 h-6" />
          </a>
        </motion.div>

      </div>
    </div>
  );
}
